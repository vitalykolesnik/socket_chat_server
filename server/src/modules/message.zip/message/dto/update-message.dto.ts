import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class UpdateMessageDTO {
  @IsNotEmpty()
  @IsString()
  @IsOptional()
  text: string;
}
