import { Server } from 'socket.io';
import {
  // ConnectedSocket,
  // MessageBody,
  // SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
// import { CustomSocketInterface } from '@app/types/customSocket.interface';
// import { MessageService } from '@app/modules/message/message.service';
// import { CreateMessageDTO } from '@app/modules/message/dto/create-message.dto';
// import { Body } from '@nestjs/common';
// import { Client } from '@app/decorators/client.decorator';

@WebSocketGateway()
export class MessageGateway {
  @WebSocketServer() server: Server;

  // constructor(private readonly messageService: MessageService) {}

  // @SubscribeMessage('createMessage')
  // async create(
  //   @MessageBody() createMessageDto: CreateMessageDTO,
  //   @Client('userName') user: string,
  // ) {
  //   const message = await this.messageService.createMessage(
  //     createMessageDto,
  //     user,
  //   );
  //   this.server.emit('requireUpdateMessageList');
  //   return message;
  // }

  // @SubscribeMessage('getMessageList')
  // async findAll(@ConnectedSocket() socket: CustomSocketInterface) {
  //   const messages = await this.messageService.getAllMessages();
  //   socket.emit('updateMessageList', { messages });
  //   return messages;
  // }

  // @SubscribeMessage('deleteMessage')
  // async delete(@Body('id') messageId: string) {
  //   await this.messageService.deleteMessage(messageId);
  //   this.server.emit('requireUpdateMessageList');
  // }
}
