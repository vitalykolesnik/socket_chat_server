import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';
import { MessageGateway } from '@app/modules/message/message.gateway';
import { MessageService } from '@app/modules/message/message.service';
import { MessageEntity } from '@app/modules/message/entities/message.entity';

@Module({
  imports: [TypeOrmModule.forFeature([MessageEntity])],
  providers: [MessageGateway, MessageService],
  exports: [MessageSocketModule],
})
export class MessageSocketModule {}
